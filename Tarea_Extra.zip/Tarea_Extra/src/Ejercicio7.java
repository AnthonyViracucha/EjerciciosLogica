import java.util.Scanner;
import java.util.Arrays;

public class Ejercicio7 {

    public static void leerPatas(int[] patas) {
        Scanner teclado= new Scanner(System.in);
        for (int i = 0; i < 4; i++) {
            System.out.print("Ingrese altura de la pata #" + (i + 1) + ": ");
            patas[i] = teclado.nextInt();
        }
    }

  
    public static void verificarMesa(int[] patas) {
        Arrays.sort(patas); 

        boolean cuatroIguales = (patas[0] == patas[3]);
        boolean tresIguales = (patas[0] == patas[2]) || (patas[1] == patas[3]);

        if (cuatroIguales) {
            System.out.println("Se puede construir una mesa de cuatro patas no coja.");
        } else if (tresIguales) {
            System.out.println("No se puede construir una de cuatro patas no coja.");
            System.out.println("Pero se puede construir una mesa de tres patas no coja.");
        } else {
            System.out.println("No se puede construir una mesa estable.");
        }
    }

    public static void main(String[] args) {
        int[] patas = new int[4];
        leerPatas(patas);
        verificarMesa(patas);
    }
}
