import java.util.Scanner;

public class Ejercicio9 {

    
    public static double obtenerAprima(double a) {
        return 2 * a;
    }

    public static double calcularOperacion(double aPrima, double b, double c, double d, double e) {
        double resultado = aPrima * b;
        resultado = resultado * c;
        resultado = resultado * d;
        resultado = resultado * e;
        return resultado;
    }

    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);

        System.out.print("Ingrese valor de a: ");
        double a = teclado.nextDouble();
        System.out.print("Ingrese valor de b: ");
        double b = teclado.nextDouble();
        System.out.print("Ingrese valor de c: ");
        double c = teclado.nextDouble();
        System.out.print("Ingrese valor de d: ");
        double d = teclado.nextDouble();
        System.out.print("Ingrese valor de e: ");
        double e = teclado.nextDouble();

        double aPrima = obtenerAprima(a);

        double resultado = calcularOperacion(aPrima, b, c, d, e);

        System.out.printf("El resultado de (((a' * b) * c) * d) * e es: %.2f\n", resultado);
    }
}
