import java.util.Scanner;

public class Ejercicio1 {
  
    public static void Gramos(double kilos) {
        System.out.println("Gramos: " + (kilos * 1000));
    }

    public static void Libras(double kilos) {
        System.out.println("Libras: " + (kilos * 2.20462));
    }

    public static void Toneladas(double kilos) {
        System.out.println("Toneladas: " + (kilos / 1000));
    }

  public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese el peso en kilos: ");
        double kilos = teclado.nextDouble();
        Gramos(kilos);
        Libras(kilos);
        Toneladas(kilos);
    }

}