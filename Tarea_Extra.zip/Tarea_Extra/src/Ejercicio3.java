import java.util.Scanner;

public class Ejercicio3 {

    public static void capturarTrabajadores() {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese el número de trabajadores: ");
        int n = teclado.nextInt();

        int mecanica = 0, pintura = 0, administrativa = 0;

        for (int i = 1; i <= n; i++) {
            System.out.print("Código del trabajador " + i + ": ");
            String codigoTrabajador = teclado.next();

            int seccion;
            do {
                System.out.print("Código de sección (1. Mecánica, 2. Pintura, 3. Administrativa): ");
                seccion = teclado.nextInt();
                if (seccion < 1 || seccion > 3) {
                    System.out.println("Intente de nuevo");
                }
            } while (seccion < 1 || seccion > 3);

            switch (seccion) {
                case 1:
                    mecanica++;
                    break;
                case 2:
                    pintura++;
                    break;
                case 3:
                    administrativa++;
                    break;
                default:
                  
                    System.out.println("Error ");
            }
        }

        mostrarResumenSecciones(mecanica, pintura, administrativa);
    }

    public static void mostrarResumenSecciones(int mec, int pin, int adm) {
        System.out.println("Trabajadores por sección:");
        System.out.println("Mecánica: " + mec);
        System.out.println("Pintura: " + pin);
        System.out.println("Administrativa: " + adm);
    }

    public static void main(String[] args) {
        capturarTrabajadores();
    }
}
