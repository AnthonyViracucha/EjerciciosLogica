import java.util.Scanner;

public class Ejercicio8 {

    public static double calcularPromedio(double[] notas, int[] creditos) {
        double sumaNotasPorCredito = 0;
        int sumaCreditos = 0;

        for (int i = 0; i < notas.length; i++) {
            sumaNotasPorCredito += notas[i] * creditos[i];
            sumaCreditos += creditos[i];
        }

        if (sumaCreditos == 0) {
            return 0;
        }
        return sumaNotasPorCredito / sumaCreditos;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese el número de materias: ");
        int n = teclado.nextInt();

        double[] notas = new double[n];
        int[] creditos = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Ingrese la nota de la materia " + (i + 1) + ": ");
            notas[i] = teclado.nextDouble();

            System.out.print("Ingrese el número de créditos de la materia " + (i + 1) + ": ");
            creditos[i] = teclado.nextInt();
        }

        double promedio = calcularPromedio(notas, creditos);
        System.out.printf("El promedio ponderado del estudiante es: %.2f\n", promedio);
    }
}
