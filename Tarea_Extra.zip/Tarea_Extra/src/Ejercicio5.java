import java.util.Scanner;

public class Ejercicio5 {

    public static void ingresarDatos(String[] nombres, int[] habitantes, double[] temperaturas) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < nombres.length; i++) {
            System.out.println("Ciudad #" + (i + 1));
            System.out.print("Nombre: ");
            nombres[i] = teclado.nextLine();
            System.out.print("Cantidad de habitantes: ");
            habitantes[i] = teclado.nextInt();
            System.out.print("Temperatura media mensual: ");
            temperaturas[i] = teclado.nextDouble();
            teclado.nextLine(); 
        }
    }

    public static double calcularTemperaturaMedia(double[] temperaturas) {
        double suma = 0;
        for (double temp : temperaturas) {
            suma += temp;
        }
        return suma / temperaturas.length;
    }

    public static int buscarMayorPoblacion(int[] habitantes) {
        int max = habitantes[0];
        int indice = 0;
        for (int i = 1; i < habitantes.length; i++) {
            if (habitantes[i] > max) {
                max = habitantes[i];
                indice = i;
            }
        }
        return indice;
    }

    public static int buscarMenorTemperatura(double[] temperaturas) {
        double min = temperaturas[0];
        int indice = 0;
        for (int i = 1; i < temperaturas.length; i++) {
            if (temperaturas[i] <= min) {
                min = temperaturas[i];
                indice = i;
            }
        }
        return indice;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de ciudades: ");
        int n = teclado.nextInt();
       

        String[] nombres = new String[n];
        int[] habitantes = new int[n];
        double[] temperaturas = new double[n];

        ingresarDatos(nombres, habitantes, temperaturas);

        double tempMediaAnual = calcularTemperaturaMedia(temperaturas);
        System.out.printf("Temperatura media anual de todas las ciudades: %.2f °C\n", tempMediaAnual);

        int indiceMayorPob = buscarMayorPoblacion(habitantes);
        System.out.println("Ciudad con mayor población:");
        System.out.println("Nombre: " + nombres[indiceMayorPob]);
        System.out.println("Habitantes: " + habitantes[indiceMayorPob]);
        System.out.println("Temperatura media: " + temperaturas[indiceMayorPob] + " °C");

        int indiceMenorTemp = buscarMenorTemperatura(temperaturas);
        System.out.println("Ciudad con menor temperatura (última encontrada si hay varias):");
        System.out.println("Nombre: " + nombres[indiceMenorTemp]);
        System.out.println("Habitantes: " + habitantes[indiceMenorTemp]);
        System.out.println("Temperatura media: " + temperaturas[indiceMenorTemp] + " °C");
    }
}
