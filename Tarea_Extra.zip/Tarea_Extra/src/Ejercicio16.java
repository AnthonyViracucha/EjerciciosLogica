import java.util.Scanner;

public class Ejercicio16{

    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static int contarDigitosPares(int numero) {
        int pares = 0;
        numero = Math.abs(numero); 
        while (numero > 0) {
            int digito = numero % 10;
            if (digito % 2 == 0) {
                pares++;
            }
            numero /= 10;
        }
        return pares;
    }

    public static void buscarPrimoConMasPares() {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("ingrese número " + (i + 1) + ": ");
            numeros[i] = teclado.nextInt();
        }

        int posicion = -1;
        int maxPares = -1;

        for (int i = 0; i < 10; i++) {
            if (esPrimo(numeros[i])) {
                int pares = contarDigitosPares(numeros[i]);
                if (pares > maxPares) {
                    maxPares = pares;
                    posicion = i;
                }
            }
        }

        if (posicion != -1) {
            System.out.println("el número primo con mayor cantidad de dígitos pares está en la posición: " + posicion);
        } else {
            System.out.println("no se encontró ningún número primo");
        }
    }

    public static void main(String[] args) {
        buscarPrimoConMasPares();
    }
}
