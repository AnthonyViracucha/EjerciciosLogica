import java.util.Scanner;

public class Ejercicio18 {

    public static void contarDos() {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[10];
        int contador = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("ingrese número " + (i + 1) + ": ");
            numeros[i] = teclado.nextInt();
        }

        for (int i = 0; i < 10; i++) {
            int num = Math.abs(numeros[i]);

            while (num > 0) {
                int digito = num % 10;
                if (digito == 2) {
                    contador++;
                }
                num = num / 10;
            }
        }

        System.out.println("el dígito 2 aparece " + contador + " veces en total");
    }

    public static void main(String[] args) {
        contarDos();
    }
}
